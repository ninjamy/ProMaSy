require "application_system_test_case"

class EditHistoriesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit edit_histories_url
  #
  #   assert_selector "h1", text: "EditHistory"
  # end
end
