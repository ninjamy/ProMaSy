require "application_system_test_case"

class WorkTypesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit work_types_url
  #
  #   assert_selector "h1", text: "WorkType"
  # end
end
