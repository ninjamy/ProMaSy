require "application_system_test_case"

class TimeLinesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit time_lines_url
  #
  #   assert_selector "h1", text: "TimeLine"
  # end
end
