require "application_system_test_case"

class PortfoliosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit portfolios_url
  #
  #   assert_selector "h1", text: "Portfolio"
  # end
end
