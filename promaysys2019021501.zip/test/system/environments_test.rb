require "application_system_test_case"

class EnvironmentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit environments_url
  #
  #   assert_selector "h1", text: "Environment"
  # end
end
