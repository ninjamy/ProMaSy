require "application_system_test_case"

class WorksTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit works_url
  #
  #   assert_selector "h1", text: "Work"
  # end
end
