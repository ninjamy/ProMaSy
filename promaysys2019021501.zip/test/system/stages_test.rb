require "application_system_test_case"

class StagesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit stages_url
  #
  #   assert_selector "h1", text: "Stage"
  # end
end
