require "application_system_test_case"

class TaskStatusesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit task_statuses_url
  #
  #   assert_selector "h1", text: "TaskStatus"
  # end
end
