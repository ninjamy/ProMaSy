require "application_system_test_case"

class LevelOfEffortsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit level_of_efforts_url
  #
  #   assert_selector "h1", text: "LevelOfEffort"
  # end
end
