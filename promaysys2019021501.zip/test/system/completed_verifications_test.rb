require "application_system_test_case"

class CompletedVerificationsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit completed_verifications_url
  #
  #   assert_selector "h1", text: "CompletedVerification"
  # end
end
