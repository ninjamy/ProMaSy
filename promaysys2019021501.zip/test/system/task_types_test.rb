require "application_system_test_case"

class TaskTypesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit task_types_url
  #
  #   assert_selector "h1", text: "TaskType"
  # end
end
