require "application_system_test_case"

class UserAccessesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit user_accesses_url
  #
  #   assert_selector "h1", text: "UserAccess"
  # end
end
