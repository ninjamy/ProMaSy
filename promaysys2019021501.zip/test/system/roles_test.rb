require "application_system_test_case"

class RolesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit roles_url
  #
  #   assert_selector "h1", text: "Role"
  # end
end
