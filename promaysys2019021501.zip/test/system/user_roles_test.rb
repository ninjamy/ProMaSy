require "application_system_test_case"

class UserRolesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit user_roles_url
  #
  #   assert_selector "h1", text: "UserRole"
  # end
end
