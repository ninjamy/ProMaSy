require "application_system_test_case"

class WorkGroupsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit work_groups_url
  #
  #   assert_selector "h1", text: "WorkGroup"
  # end
end
