require 'test_helper'

class CompVerIdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
