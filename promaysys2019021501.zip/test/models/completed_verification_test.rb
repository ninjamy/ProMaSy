require 'test_helper'

class CompletedVerificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
