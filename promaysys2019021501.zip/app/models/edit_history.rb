class EditHistory < ApplicationRecord
end
