class TaskType < ApplicationRecord
end
