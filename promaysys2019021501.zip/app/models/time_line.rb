class TimeLine < ApplicationRecord
end
