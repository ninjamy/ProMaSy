class WorkType < ApplicationRecord
end
