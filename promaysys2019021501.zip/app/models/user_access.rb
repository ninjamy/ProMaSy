class UserAccess < ApplicationRecord
end
