class Work < ApplicationRecord
end
