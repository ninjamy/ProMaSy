class UserRole < ApplicationRecord
end
