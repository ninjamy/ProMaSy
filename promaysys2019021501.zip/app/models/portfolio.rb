class Portfolio < ApplicationRecord
end
