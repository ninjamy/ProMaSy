class CompletedVerification < ApplicationRecord
end
