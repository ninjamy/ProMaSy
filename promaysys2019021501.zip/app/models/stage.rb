class Stage < ApplicationRecord
end
