class LevelOfEffort < ApplicationRecord
end
