class Environment < ApplicationRecord
end
