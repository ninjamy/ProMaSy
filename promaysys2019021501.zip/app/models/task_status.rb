class TaskStatus < ApplicationRecord
end
